# Tienda Express – Reto ADSO

Prototipo para registrar productos, crear pedidos y consultar/cambiar su estado.
Hecho con **React + TypeScript + Vite**. Los datos viven en memoria (arreglos en el estado de React).

## Ejecutar

```bash
npm install
npm run dev
```

Abre la URL que muestra la terminal (normalmente http://localhost:5173).

## Funcionalidades

- Registrar productos (nombre, categoría, precio, stock) con validaciones.
- Registrar pedidos (cliente, producto, cantidad, fecha); valida que haya stock suficiente y lo descuenta.
- Listar productos y pedidos.
- Cambiar el estado del pedido: Pendiente → En proceso → Entregado.

## Estructura

```
src/
  App.tsx              estado global (productos y pedidos) y navegación
  types.ts             tipos Product, Order, OrderStatus
  components/
    ProductForm.tsx    formulario + validaciones de productos
    ProductList.tsx    listado de productos
    OrderForm.tsx      formulario + validaciones de pedidos
    OrderList.tsx      listado de pedidos y cambio de estado
  styles.css
```

## Requerimientos

- RF1: registrar productos y pedidos con validación de campos obligatorios.
- RF2: consultar el estado de los pedidos y poder cambiarlo.
- RNF1: la interfaz debe ser clara y usable en computador y celular.
