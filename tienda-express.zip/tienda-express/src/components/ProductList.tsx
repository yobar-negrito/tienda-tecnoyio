import type { Product } from '../types'

interface Props {
  products: Product[]
}

export const money = (n: number) =>
  new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    maximumFractionDigits: 0,
  }).format(n)

export default function ProductList({ products }: Props) {
  return (
    <section className="panel">
      <h2>Productos ({products.length})</h2>
      {products.length === 0 ? (
        <p className="empty">Aún no hay productos. Registra el primero con el formulario.</p>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Producto</th>
                <th>Categoría</th>
                <th className="num">Precio</th>
                <th className="num">Stock</th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id}>
                  <td>{p.name}</td>
                  <td>{p.category}</td>
                  <td className="num">{money(p.price)}</td>
                  <td className="num">
                    <span className={p.stock === 0 ? 'stock out' : p.stock <= 3 ? 'stock low' : 'stock'}>
                      {p.stock === 0 ? 'Agotado' : p.stock}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  )
}
