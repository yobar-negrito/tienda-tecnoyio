import { useState, type FormEvent } from 'react'
import type { FormErrors, Product } from '../types'

type Field = 'customer' | 'productId' | 'quantity' | 'date'

interface Props {
  products: Product[]
  onAdd: (data: { customer: string; productId: number; quantity: number; date: string }) => void
}

const today = () => new Date().toISOString().slice(0, 10)

export default function OrderForm({ products, onAdd }: Props) {
  const [customer, setCustomer] = useState('')
  const [productId, setProductId] = useState('')
  const [quantity, setQuantity] = useState('1')
  const [date, setDate] = useState(today())
  const [errors, setErrors] = useState<FormErrors<Field>>({})
  const [ok, setOk] = useState(false)

  const validate = (): FormErrors<Field> => {
    const e: FormErrors<Field> = {}
    if (!customer.trim()) e.customer = 'Escribe el nombre del cliente.'
    if (!productId) e.productId = 'Elige un producto.'
    const qty = Number(quantity)
    if (quantity === '' || !Number.isInteger(qty) || qty <= 0) {
      e.quantity = 'La cantidad debe ser un entero mayor que 0.'
    } else if (productId) {
      const product = products.find((p) => p.id === Number(productId))
      if (product && qty > product.stock) {
        e.quantity = `Solo hay ${product.stock} unidades disponibles.`
      }
    }
    if (!date) e.date = 'Elige la fecha del pedido.'
    return e
  }

  const handleSubmit = (ev: FormEvent) => {
    ev.preventDefault()
    const e = validate()
    setErrors(e)
    setOk(false)
    if (Object.keys(e).length > 0) return

    onAdd({
      customer: customer.trim(),
      productId: Number(productId),
      quantity: Number(quantity),
      date,
    })
    setCustomer('')
    setProductId('')
    setQuantity('1')
    setDate(today())
    setOk(true)
  }

  return (
    <form className="panel" onSubmit={handleSubmit} noValidate>
      <h2>Nuevo pedido</h2>

      <label>
        Cliente
        <input
          value={customer}
          onChange={(e) => setCustomer(e.target.value)}
          placeholder="Nombre del cliente"
          aria-invalid={!!errors.customer}
        />
        {errors.customer && <span className="error">{errors.customer}</span>}
      </label>

      <label>
        Producto
        <select
          value={productId}
          onChange={(e) => setProductId(e.target.value)}
          aria-invalid={!!errors.productId}
        >
          <option value="">Selecciona…</option>
          {products.map((p) => (
            <option key={p.id} value={p.id} disabled={p.stock === 0}>
              {p.name} ({p.stock === 0 ? 'agotado' : `${p.stock} disp.`})
            </option>
          ))}
        </select>
        {errors.productId && <span className="error">{errors.productId}</span>}
      </label>

      <div className="row">
        <label>
          Cantidad
          <input
            type="number"
            min="1"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
            aria-invalid={!!errors.quantity}
          />
          {errors.quantity && <span className="error">{errors.quantity}</span>}
        </label>

        <label>
          Fecha
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            aria-invalid={!!errors.date}
          />
          {errors.date && <span className="error">{errors.date}</span>}
        </label>
      </div>

      <button type="submit" className="btn-primary" disabled={products.length === 0}>
        Crear pedido
      </button>
      {ok && <p className="success">Pedido creado como Pendiente.</p>}
    </form>
  )
}
