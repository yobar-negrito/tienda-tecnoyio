import { useState, type FormEvent } from 'react'
import type { FormErrors, Product } from '../types'

type Field = 'name' | 'category' | 'price' | 'stock'

interface Props {
  onAdd: (data: Omit<Product, 'id'>) => void
}

const CATEGORIES = ['Audio', 'Cómputo', 'Celulares', 'Accesorios', 'Almacenamiento']

export default function ProductForm({ onAdd }: Props) {
  const [name, setName] = useState('')
  const [category, setCategory] = useState('')
  const [price, setPrice] = useState('')
  const [stock, setStock] = useState('')
  const [errors, setErrors] = useState<FormErrors<Field>>({})
  const [ok, setOk] = useState(false)

  const validate = (): FormErrors<Field> => {
    const e: FormErrors<Field> = {}
    if (!name.trim()) e.name = 'Escribe el nombre del producto.'
    if (!category) e.category = 'Elige una categoría.'
    if (price === '' || Number(price) <= 0) e.price = 'El precio debe ser mayor que 0.'
    if (stock === '' || !Number.isInteger(Number(stock)) || Number(stock) < 0)
      e.stock = 'El stock debe ser un entero de 0 o más.'
    return e
  }

  const handleSubmit = (ev: FormEvent) => {
    ev.preventDefault()
    const e = validate()
    setErrors(e)
    setOk(false)
    if (Object.keys(e).length > 0) return

    onAdd({
      name: name.trim(),
      category,
      price: Number(price),
      stock: Number(stock),
    })
    setName('')
    setCategory('')
    setPrice('')
    setStock('')
    setOk(true)
  }

  return (
    <form className="panel" onSubmit={handleSubmit} noValidate>
      <h2>Nuevo producto</h2>

      <label>
        Nombre
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Ej: Audífonos Bluetooth"
          aria-invalid={!!errors.name}
        />
        {errors.name && <span className="error">{errors.name}</span>}
      </label>

      <label>
        Categoría
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          aria-invalid={!!errors.category}
        >
          <option value="">Selecciona…</option>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        {errors.category && <span className="error">{errors.category}</span>}
      </label>

      <div className="row">
        <label>
          Precio (COP)
          <input
            type="number"
            min="0"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            aria-invalid={!!errors.price}
          />
          {errors.price && <span className="error">{errors.price}</span>}
        </label>

        <label>
          Stock
          <input
            type="number"
            min="0"
            value={stock}
            onChange={(e) => setStock(e.target.value)}
            aria-invalid={!!errors.stock}
          />
          {errors.stock && <span className="error">{errors.stock}</span>}
        </label>
      </div>

      <button type="submit" className="btn-primary">
        Guardar producto
      </button>
      {ok && <p className="success">Producto guardado.</p>}
    </form>
  )
}
