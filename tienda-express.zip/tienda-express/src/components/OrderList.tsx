import { ORDER_STATUSES, type Order, type OrderStatus, type Product } from '../types'
import { money } from './ProductList'

interface Props {
  orders: Order[]
  products: Product[]
  onChangeStatus: (orderId: number, status: OrderStatus) => void
}

const statusClass: Record<OrderStatus, string> = {
  Pendiente: 'badge pending',
  'En proceso': 'badge progress',
  Entregado: 'badge done',
}

export default function OrderList({ orders, products, onChangeStatus }: Props) {
  return (
    <section className="panel">
      <h2>Pedidos ({orders.length})</h2>
      {orders.length === 0 ? (
        <p className="empty">Todavía no hay pedidos. Crea uno para seguir su estado aquí.</p>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Cliente</th>
                <th>Producto</th>
                <th className="num">Cant.</th>
                <th className="num">Total</th>
                <th>Fecha</th>
                <th>Estado</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => {
                const product = products.find((p) => p.id === o.productId)
                return (
                  <tr key={o.id}>
                    <td>{o.id}</td>
                    <td>{o.customer}</td>
                    <td>{product?.name ?? '—'}</td>
                    <td className="num">{o.quantity}</td>
                    <td className="num">{product ? money(product.price * o.quantity) : '—'}</td>
                    <td>{o.date}</td>
                    <td>
                      <select
                        className={statusClass[o.status]}
                        value={o.status}
                        aria-label={`Estado del pedido ${o.id}`}
                        onChange={(e) => onChangeStatus(o.id, e.target.value as OrderStatus)}
                      >
                        {ORDER_STATUSES.map((s) => (
                          <option key={s} value={s}>
                            {s}
                          </option>
                        ))}
                      </select>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  )
}
