export interface Product {
  id: number
  name: string
  category: string
  price: number
  stock: number
}

export type OrderStatus = 'Pendiente' | 'En proceso' | 'Entregado'

export const ORDER_STATUSES: OrderStatus[] = ['Pendiente', 'En proceso', 'Entregado']

export interface Order {
  id: number
  customer: string
  productId: number
  quantity: number
  date: string
  status: OrderStatus
}

export type FormErrors<T extends string> = Partial<Record<T, string>>
