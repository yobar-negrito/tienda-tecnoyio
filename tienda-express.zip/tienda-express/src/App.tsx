import { useState } from 'react'
import type { Order, OrderStatus, Product } from './types'
import ProductForm from './components/ProductForm'
import ProductList from './components/ProductList'
import OrderForm from './components/OrderForm'
import OrderList from './components/OrderList'

type Tab = 'productos' | 'pedidos'

// Datos en memoria (vectores). Se pierden al recargar la página.
const INITIAL_PRODUCTS: Product[] = [
  { id: 1, name: 'Audífonos Bluetooth', category: 'Audio', price: 89000, stock: 12 },
  { id: 2, name: 'Mouse inalámbrico', category: 'Accesorios', price: 45000, stock: 20 },
  { id: 3, name: 'Memoria USB 64 GB', category: 'Almacenamiento', price: 32000, stock: 3 },
]

export default function App() {
  const [tab, setTab] = useState<Tab>('productos')
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS)
  const [orders, setOrders] = useState<Order[]>([])

  const addProduct = (data: Omit<Product, 'id'>) => {
    setProducts((prev) => [...prev, { ...data, id: prev.length ? Math.max(...prev.map((p) => p.id)) + 1 : 1 }])
  }

  const addOrder = (data: Pick<Order, 'customer' | 'productId' | 'quantity' | 'date'>) => {
    setOrders((prev) => [
      ...prev,
      { ...data, id: prev.length ? Math.max(...prev.map((o) => o.id)) + 1 : 1, status: 'Pendiente' },
    ])
    // Descuenta el stock del producto pedido
    setProducts((prev) =>
      prev.map((p) => (p.id === data.productId ? { ...p, stock: p.stock - data.quantity } : p)),
    )
  }

  const changeStatus = (orderId: number, status: OrderStatus) => {
    setOrders((prev) => prev.map((o) => (o.id === orderId ? { ...o, status } : o)))
  }

  const pending = orders.filter((o) => o.status !== 'Entregado').length

  return (
    <>
      <header className="topbar">
        <div className="awning" aria-hidden="true" />
        <div className="topbar-inner">
          <h1>Tienda Express</h1>
          <nav className="tabs" aria-label="Secciones">
            <button
              className={tab === 'productos' ? 'tab active' : 'tab'}
              onClick={() => setTab('productos')}
            >
              Productos
            </button>
            <button
              className={tab === 'pedidos' ? 'tab active' : 'tab'}
              onClick={() => setTab('pedidos')}
            >
              Pedidos{pending > 0 && <span className="count">{pending}</span>}
            </button>
          </nav>
        </div>
      </header>

      <main className="layout">
        {tab === 'productos' ? (
          <>
            <ProductForm onAdd={addProduct} />
            <ProductList products={products} />
          </>
        ) : (
          <>
            <OrderForm products={products} onAdd={addOrder} />
            <OrderList orders={orders} products={products} onChangeStatus={changeStatus} />
          </>
        )}
      </main>
    </>
  )
}
